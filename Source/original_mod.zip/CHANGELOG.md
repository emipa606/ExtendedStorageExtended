# Version 0.1.0.0

- Initial Work

# Version 0.2.0.2

+ Added MassiveWeaponsRack.
+ Added image masks for MeatHooks.
+ Added internal-only document generation tools.
* Consolidated Defs for faster patching by 3rd parties.

# Version 0.3.0.1

* Changed ExplosivesContainer to default to 'Grenades' CategoryDef instead of listing unique ThingsDefs.
* Updated for r1.0

# Version 0.4.0.3

* Changed LargeWeaponsRack to allow non-vanilla weapons to be stored.
* Updated internals to be easier to mod.
* Minor balance tweaks.
+ Added AnimalFeedTrough.

# Version 0.5.0.1

+ Added Meat Hangers (Tribal).
+ Added Weapons Stack (Tribal).
* Updated Meat Hooks with better Cleanliness.
* Updated Large Weapons Rack to require Research and added protection to weapons and increase in stats to offset.
* Patched HazMat Container from Extended Storage to increase capacity as Uranium no longer has the x10 multiplier.
* Trivial balance tweaks.
* Updated for r1.0

# Version 0.6.0.1b

* Testing expected changes from Extended Storage
* Minor documentation corrections.

# Version 0.6.0.2

* Updated for r1.1
* Minor documentation corrections.

